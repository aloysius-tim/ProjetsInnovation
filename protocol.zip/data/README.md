# Data

## Project idea
A project idea if composed of :

    - id: The unique identifier of the project idea
    - name: Name of the project idea
    - description: Description of the project idea
    - technology: Technology of the project idea
    - owner: Person object who represent the owner of the project idea
    - collaborators: Interested people of the project idea

## Person
A person if composed of :

    - id: The unique identifier of the person
    - username: The name of the person
    - mail: The mail address of the person 
    
## Error
An error is composed of :

    - message: The message of the error