# LIST
List the project ideas.

## Examples
### Request
```json
{
    "action": "LIST",
    "data": {}
}
```

### Response
On success
```json
{
    "status": "OK",
    "errors": [],
    "data": {
        "projects": [ 
            {
                "id": 123,
                "name": "Idea 1",
                "description": "Text description...",
                "technology": "Java",
                "owner": {
                    "id": 1,
                    "username": "John DOE",
                    "mail": "test@test.com"
                },
                "collaborators": [
                    {
                        "id": 2,
                        "username": "John DOE",
                        "mail": "test@test.com"
                    },
                    {
                        "id": 3,
                        "username": "John DOE",
                        "mail": "test@test.com"
                    }
                ]
            },
            {
                "id": 124,
                "name": "Idea 2",
                "desc": "Text description...",
                "tech": "C++",
                "owner": {
                    "id": 1,
                    "username": "John DOE",
                    "mail": "test@test.com"
                },
                "collaborators": [
                    {
                        "id": 2,
                        "username": "John DOE",
                        "mail": "test@test.com"
                    },
                    {
                        "id": 3,
                        "username": "John DOE",
                        "mail": "test@test.com"
                    }
                ]
            }
        ]
    }
}
```

On error(s)
```json
{
    "status": "KO",
    "errors": [],
    "data": {}
}
```