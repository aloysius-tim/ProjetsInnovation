# ADD
Add a new project idea. You must enter the following parameters :

    - name: Name of the project idea
    - description: Description of the project idea
    - technology: Technology of the project idea
    - owner: The owner of the project idea
        - username: Name of the owner of the project idea
        - mail: Mail address of the owner of the project idea
    
## Examples
### Request
```json
{
    "action": "ADD",
    "data": {
        "id": null,
        "name": "Idea 1",
        "description": "Text description...",
        "technology": "Java",
        "owner": {
          "id": 1,
          "username": "John DOE",
          "mail": "test@test.com"
        }
    }
}
```

### Response
On Success
```json
{
    "status": "OK",
    "errors": [],
    "data": {
        "project": {
            "id": 123,
            "name": "Idea 1",
            "description": "Text description...",
            "technology": "Java",
            "owner": {
                "id": 1,
                "username": "John DOE",
                "mail": "test@test.com"
            },
            "collaborators": []
        }
    }
}
```

On error(s)
```json
{
    "status": "KO",
    "errors": [
        {
            "message": "Name already exists."
        },
        {
            "message": "Mail address is incorrect."
        }
    ],
    "data": {}
}
```