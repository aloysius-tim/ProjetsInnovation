# JOIN
Join a project idea. You must enter the following parameters :

    - id: The unique identifier of the project idea
    - person: The person who wants to join the project idea
        - username: Name of the owner of the project idea
        - mail: Mail address of the owner of the project idea
    
## Examples
### Request
```json
{
    "action": "JOIN",
    "data": {
        "id": 123,
        "person": {
            "id": 1,
            "username": "John DOE",
            "mail": "test@test.com"
        }
    }
}
```

### Response
On success
```json
{
    "status": "OK",
    "errors": [],
    "data": {}
}
```

On error(s)
```json
{
    "status": "KO",
    "errors": [
        {
            "message": "Unknown project idea id."
        },
        {
            "message": "Mail address is incorrect."
        }
    ],
    "data": {}
}
```