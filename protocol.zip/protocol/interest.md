# INTEREST
List people interested in a project idea. You must enter the following parameters :

    - id: The unique identifier of a project idea
    
## Examples
### Request
```json
{
    "action": "INTEREST",
    "data": {
        "id": 123
    }
}
```

### Response
On success
```json
{
    "status": "OK",
    "errors": [],
    "data": {
        "people": [
            {
                "id": 1,
                "username": "John DOE",
                "mail": "test@test.com"
            },
            {
                "id": 1,
                "username": "John DOE",
                "mail": "test2@test.com"
            }
        ]
    }
}
```

On error(s)
```json
{
    "status": "KO",
    "errors": [
        {
            "message": "Unknown project idea id."
        }
    ],
    "data": {}
}
```