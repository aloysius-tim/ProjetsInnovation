# CLOSE
Close connection.

## Examples
### Request
```json
{
    "action": "CLOSE",
    "data": {}
}
```

### Response
On success
```json
{
    "status": "OK",
    "errors": [],
    "data": {}
}
```

On error(s)
```json
{
    "status": "KO",
    "errors": [],
    "data": {}
}
```