# Protocol

* [ADD](add.md) : Add a new project idea
* [JOIN](join.md) : Join a project idea
* [LIST](list.md) : List the project ideas
* [INTEREST](interest.md) : List people interested in a project idea
* [CLOSE](close.md) : Close socket

Actions are not case sensitive.

## Buffer
Use DataOutputStream with writeUTF and DataInputStream readUTF.

## Request
A request is composed of :

    - action: Action to perform
    - data: Parameters of the action to perform

## Response
A response is composed of :

    - status: The status of the return of execution
    - errors: An array of errors objects
    - data: An object of return data